package com.pedido.pedidoTiendaDeVideojuegos.controller;

import com.pedido.pedidoTiendaDeVideojuegos.model.PedidoTienda;
import com.pedido.pedidoTiendaDeVideojuegos.service.PedidoTiendaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController

@RequestMapping("/pedidos")
public class PedidoTiendaController {

    @Autowired
    private PedidoTiendaService service;

    @GetMapping
    public List<PedidoTienda> ListarPedidos() {
        return service.ListarPedidos();
    }

    @GetMapping("/pedidos/{id}")
    public Optional<PedidoTienda> ObtenerPorId(@PathVariable Integer id) {
        return service.ObtenerPorId(id);
    }

    @PostMapping("/guardar")
    public PedidoTienda GuardarPedido(@RequestBody PedidoTienda pedido) {
        return service.GuardarPedido(pedido);
    }

    @DeleteMapping("/Eliminar/{id}")
    public String eliminarPedido(@PathVariable Integer id) {
    
         Optional<PedidoTienda> pedido = service.ObtenerPorId(id);
       if (pedido.isPresent()) {
          service.eliminarPedido(id);
          return "Pedido eliminado correctamente";
       }else {
             return "Pedido no encontrado con ID: " + id;
       }
    }
    @PutMapping("/actualizar/{id}")
    public String actualizarPedido(@PathVariable Integer id, @RequestBody PedidoTienda pedidoActualizado) {
        Optional<PedidoTienda> pedidoExistente = service.ObtenerPorId(id);
        if (pedidoExistente.isPresent()) {
            service.actualizarPedido(id, pedidoActualizado);
            return "Pedido actualizado correctamente";
        } else {
            return "Pedido no encontrado con ID: " + id;
        }

    }
}
