package com.pedido.pedidoTiendaDeVideojuegos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PedidoTiendaDeVideojuegosApplication {

	public static void main(String[] args) {
		SpringApplication.run(PedidoTiendaDeVideojuegosApplication.class, args);
	}

}
