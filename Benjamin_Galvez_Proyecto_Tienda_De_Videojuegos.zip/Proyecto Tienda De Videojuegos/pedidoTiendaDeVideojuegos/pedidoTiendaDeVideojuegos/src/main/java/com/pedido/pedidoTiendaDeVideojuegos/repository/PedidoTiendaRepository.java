package com.pedido.pedidoTiendaDeVideojuegos.repository;

import com.pedido.pedidoTiendaDeVideojuegos.model.PedidoTienda;
import org.springframework.data.jpa.repository.JpaRepository;

//import java.util.List;
//import java.util.Optional;

public interface PedidoTiendaRepository extends JpaRepository<PedidoTienda, Integer> {

}
