package com.pedido.pedidoTiendaDeVideojuegos.service;

import com.pedido.pedidoTiendaDeVideojuegos.model.PedidoTienda;
import com.pedido.pedidoTiendaDeVideojuegos.repository.PedidoTiendaRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service

public class PedidoTiendaService {

    private PedidoTiendaRepository repository;

    public List<PedidoTienda> ListarPedidos() {
        return repository.findAll();
    }

    public Optional<PedidoTienda> ObtenerPorId(Integer id) {
        return repository.findById(id);
    }

    public PedidoTienda GuardarPedido(PedidoTienda pedido) {
        return repository.save(pedido);
    }

    public void eliminarPedido(Integer id) {
        repository.deleteById(id);
    }

    public PedidoTienda actualizarPedido(Integer id, PedidoTienda pedidoActualizado)  {
        pedidoActualizado.setId(id);
        return repository.save(pedidoActualizado);
    }   
}
