package com.pedido.pedidoTiendaDeVideojuegos.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "pedido")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PedidoTienda {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotBlank(message = "El Producto no debe estar vacio")
    private String producto;

    @NotBlank(message = "La fecha del pedido no debe estar vacia")
    private String fecha;

    @NotNull(message = "El estado del pedido no debe estar vacio")
    private String estado;

    @NotNull(message = "La cantidad no debe estar vacia")
    private Integer cantidad;

    @NotNull(message = "El precio no debe estar vacio")
    private Double precio;

    @NotBlank(message = "El nombre del cliente no debe estar vacio")
    private String clienteNombre;

    @NotBlank(message = "El email no debe estar vacio")
    private String email;

    @NotBlank(message = "El método de pago no debe estar vacio")
    private String metodoPago;
}
