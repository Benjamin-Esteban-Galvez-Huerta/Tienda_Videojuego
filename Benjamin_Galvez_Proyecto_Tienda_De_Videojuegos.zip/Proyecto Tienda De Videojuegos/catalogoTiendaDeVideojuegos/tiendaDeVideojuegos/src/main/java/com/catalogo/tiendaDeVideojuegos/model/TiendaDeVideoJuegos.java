package com.catalogo.tiendaDeVideojuegos.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "tienda_de_videojuegos")
@Data
@NoArgsConstructor
@AllArgsConstructor

public class TiendaDeVideoJuegos {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    
    @NotBlank(message = "El nombre del videojuego no debe estar vació")
    @Column(nullable = false, length = 100)
    private String titulo;

    @NotBlank(message = "La descripción del videojuego no debe estar vacía")
    private String descripcion;

    @NotBlank(message = "El genero del videojuego no debe estar vació")
    private String genero;
    
    @Min(value = 1958, message = "El año del videojuego debe ser mayor o igual a 1958") 
    @NotNull(message = "El año del videojuego no debe estar vació")
    private Integer anio;

    @NotNull(message = "El precio del videojuego no debe ser nulo o nada")
    @DecimalMin(value = "0.0", inclusive = false, message = "El precio debe ser mayor que 0")
    private Double precio;
}
