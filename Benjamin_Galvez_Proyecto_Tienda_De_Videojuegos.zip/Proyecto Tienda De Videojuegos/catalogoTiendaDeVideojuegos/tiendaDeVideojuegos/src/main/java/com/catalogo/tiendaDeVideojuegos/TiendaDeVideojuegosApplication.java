package com.catalogo.tiendaDeVideojuegos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendaDeVideojuegosApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendaDeVideojuegosApplication.class, args);
	}

}
