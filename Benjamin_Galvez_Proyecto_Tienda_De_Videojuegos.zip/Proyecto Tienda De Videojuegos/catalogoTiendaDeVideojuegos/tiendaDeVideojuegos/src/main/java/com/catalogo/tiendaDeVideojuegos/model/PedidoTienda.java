package com.catalogo.tiendaDeVideojuegos.model;

import lombok.Data;

@Data
public class PedidoTienda {

     private Integer id;

    private String producto;

    private String fecha;

    private String estado;

    private Integer cantidad;

    private Double precio;

    private String clienteNombre;

    private String email;

    private String metodoPago;
}

