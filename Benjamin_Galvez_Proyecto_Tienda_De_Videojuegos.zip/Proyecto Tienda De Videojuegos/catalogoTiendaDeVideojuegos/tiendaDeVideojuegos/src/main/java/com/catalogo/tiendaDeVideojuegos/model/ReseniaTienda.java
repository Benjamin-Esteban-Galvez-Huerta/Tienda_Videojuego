package com.catalogo.tiendaDeVideojuegos.model;

import lombok.Data;

@Data
public class ReseniaTienda {

    private Integer id;

    private String titulo;

    private String comentario;

    private Integer calificacion;

    private String autor;
}
