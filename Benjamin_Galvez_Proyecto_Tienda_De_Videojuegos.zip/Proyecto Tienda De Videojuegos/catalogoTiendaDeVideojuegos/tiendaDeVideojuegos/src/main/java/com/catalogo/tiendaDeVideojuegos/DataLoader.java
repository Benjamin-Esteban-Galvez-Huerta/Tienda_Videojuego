package com.catalogo.tiendaDeVideojuegos;

import com.catalogo.tiendaDeVideojuegos.model.TiendaDeVideoJuegos;
import com.catalogo.tiendaDeVideojuegos.repository.TiendaDeVideoJuegosRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataLoader {

    @Bean
    CommandLineRunner init(TiendaDeVideoJuegosRepository repository) {
        return args -> {

          if (repository.count() == 0) {

            repository.save(new TiendaDeVideoJuegos(null, "The Legend of Zelda: Breath of the Wild", "Un juego de acción y aventura en un mundo abierto", "Aventura", 2017, 59.99));
            repository.save(new TiendaDeVideoJuegos(null, "Super Mario Odyssey", "Un juego de plataformas en 3D con Mario como protagonista", "Plataformas", 2017, 49.99));
            repository.save(new TiendaDeVideoJuegos(null, "Red Dead Redemption 2", "Un juego de acción y aventura en el Viejo Oeste", "Acción y Aventura", 2018, 69.99));
            repository.save(new TiendaDeVideoJuegos(null, "The Witcher 3: Wild Hunt", "Un juego de rol en un mundo abierto basado en la serie de libros de Andrzej Sapkowski", "RPG", 2015, 39.99));
            repository.save(new TiendaDeVideoJuegos(null, "Minecraft", "Un juego de construcción y supervivencia en un mundo generado por procedimientos", "Sandbox", 2011, 26.95));
            repository.save(new TiendaDeVideoJuegos(null, "The Legend of Zelda: Ocarina of Time", "Un juego de acción y aventura que revolucionó los videojuegos en 3D", "Aventura", 1998, 49.99));
            repository.save(new TiendaDeVideoJuegos(null, "Dark Souls", "Un juego de rol de acción desafiante con un diseño de mundo interconectado", "RPG de Acción", 2011, 39.99));
            repository.save(new TiendaDeVideoJuegos(null, "Final Fantasy VII", "Un clásico de los videojuegos de rol con una historia épica y personajes memorables", "RPG", 1997, 34.99));
            repository.save(new TiendaDeVideoJuegos(null, "Metal Gear Solid", "Un juego de sigilo y acción con una narrativa cinematográfica revolucionaria", "Sigilo", 1998, 29.99));
            repository.save(new TiendaDeVideoJuegos(null, "Halo: Combat Evolved", "Un juego de disparos en primera persona que definió el género en consolas", "Disparos", 2001, 24.99));
            repository.save(new TiendaDeVideoJuegos(null, "Portal 2", "Un juego de puzles con mecánicas innovadoras y narrativa satírica", "Puzles", 2011, 19.99));
            repository.save(new TiendaDeVideoJuegos(null, "Shadow of the Colossus", "Un juego de aventura donde enfrentas titánicos guardianes en un mundo desolado", "Aventura", 2005, 29.99));
            repository.save(new TiendaDeVideoJuegos(null, "Chrono Trigger", "Un clásico de los RPG con múltiples finales y viajes a través del tiempo", "RPG", 1995, 24.99));
            repository.save(new TiendaDeVideoJuegos(null, "The Last of Us", "Un juego de acción y aventura con una narrativa emotiva en un mundo post-apocalíptico", "Acción", 2013, 39.99));
            repository.save(new TiendaDeVideoJuegos(null, "God of War", "Un juego de acción épico que reimagina al protagonista en una nueva era", "Acción", 2018, 49.99));
          }
        };
     }

}
