package com.catalogo.tiendaDeVideojuegos.controller;

import com.catalogo.tiendaDeVideojuegos.model.TiendaDeVideoJuegos;
import com.catalogo.tiendaDeVideojuegos.service.TiendaDeVideoJuegosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController

@RequestMapping("/videojuegos")
public class TiendaDeVideoJuegosController {

    @Autowired
    private TiendaDeVideoJuegosService service;

    @GetMapping
    public List<TiendaDeVideoJuegos> listar() {
        return service.listar();
    }

    @GetMapping("/videojuego/{id}")
    public Optional<TiendaDeVideoJuegos> obtenerPorId(@PathVariable Integer id) {
        return service.obtenerPorId(id);
    }
    
    @PostMapping("/agregar")
    public TiendaDeVideoJuegos crearVideoJuego(@RequestBody TiendaDeVideoJuegos videojuego) {
        return service.crearVideoJuego(videojuego);
    }

    @DeleteMapping("/Eliminar/{id}")
    public String eliminarVideoJuego(@PathVariable Integer id) {
        Optional<TiendaDeVideoJuegos> videojuego = service.obtenerPorId(id);

        if (videojuego.isPresent()) {
            service.eliminarVideoJuego(id);
            return "Videojuego eliminado correctamente.";
        } else {    
           return "No se encontró el videojuego con el ID: " + id;
        }
    }

    @PutMapping("/actualizar/{id}")
    public TiendaDeVideoJuegos actualizarVideoJuego(@PathVariable Integer id, @RequestBody TiendaDeVideoJuegos videojuego) {
        Optional<TiendaDeVideoJuegos> existente = service.obtenerPorId(id);

        if (existente.isPresent()) {
            service.actualizarVideoJuego(id, videojuego);
            return "Videojuego actualizado correctamente.";
        } else {
            return "No se encontró el videojuego con el ID: " + id;
        }
    }
}
