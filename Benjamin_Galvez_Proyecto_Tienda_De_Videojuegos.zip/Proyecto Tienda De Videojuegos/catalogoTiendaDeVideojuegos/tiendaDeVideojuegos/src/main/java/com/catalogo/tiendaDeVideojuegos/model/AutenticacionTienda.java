package com.catalogo.tiendaDeVideojuegos.model;

import lombok.Data;

@Data
public class AutenticacionTienda {

    private Integer id;
    
    private String email;
    
    private String contrasenia;
    
    private String nombre;
}
