package com.catalogo.tiendaDeVideojuegos.repository;

import com.catalogo.tiendaDeVideojuegos.model.TiendaDeVideoJuegos;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TiendaDeVideoJuegosRepository extends JpaRepository<TiendaDeVideoJuegos, Integer> {

}
