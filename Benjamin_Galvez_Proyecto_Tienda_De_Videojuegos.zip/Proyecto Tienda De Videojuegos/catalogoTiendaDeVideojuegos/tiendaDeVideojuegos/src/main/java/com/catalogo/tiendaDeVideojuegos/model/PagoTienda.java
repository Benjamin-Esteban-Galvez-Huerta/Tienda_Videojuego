package com.catalogo.tiendaDeVideojuegos.model;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class PagoTienda {

    private Integer id;

    private String nombreCliente;

    private String numeroTarjeta;

    private String fechaVencimiento;

    private String codigoSeguridad;

    private BigDecimal monto;

}
