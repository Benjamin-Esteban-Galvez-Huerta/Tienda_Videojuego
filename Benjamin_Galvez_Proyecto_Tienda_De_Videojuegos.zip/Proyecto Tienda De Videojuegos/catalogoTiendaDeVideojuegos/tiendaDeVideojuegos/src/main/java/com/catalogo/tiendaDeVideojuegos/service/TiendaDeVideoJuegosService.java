package com.catalogo.tiendaDeVideojuegos.service;

import com.catalogo.tiendaDeVideojuegos.model.TiendaDeVideoJuegos;
import com.catalogo.tiendaDeVideojuegos.repository.TiendaDeVideoJuegosRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service

public class TiendaDeVideoJuegosService {

    private final TiendaDeVideoJuegosRepository repository;

    public TiendaDeVideoJuegosService(TiendaDeVideoJuegosRepository repository) {
        this.repository = repository;
    }

    public List<TiendaDeVideoJuegos> listar() {
        return repository.findAll();
    }

    public Optional<TiendaDeVideoJuegos> obtenerPorId(Integer id) {
        return repository.findById(id);
    }

    public TiendaDeVideoJuegos crearVideoJuego(TiendaDeVideoJuegos videojuego) {
        return repository.save(videojuego);
    }

    public void eliminarVideoJuego(Integer id) {
        repository.deleteById(id);
    }

    public TiendaDeVideoJuegos actualizarVideoJuego(Integer id, TiendaDeVideoJuegos videojuego) {
    videojuego.setId(id);
    return repository.save(videojuego);
    }
}
