package com.catalogo.tiendaDeVideojuegos.model;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class OrdenTienda {

    private Integer id;

    private String cliente;

    private String videojuego;

    private Integer cantidad;

    private BigDecimal precioUnitario;
}
