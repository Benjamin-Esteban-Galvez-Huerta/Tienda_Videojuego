package com.orden.ordenTiendaDeVideojuegos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdenTiendaDeVideojuegosApplicationTests {

	@Test
	void contextLoads() {
	}

}
