package com.orden.ordenTiendaDeVideojuegos.repository;

import com.orden.ordenTiendaDeVideojuegos.model.OrdenTienda;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrdenTiendaRepository extends JpaRepository<OrdenTienda, Integer> {

}
