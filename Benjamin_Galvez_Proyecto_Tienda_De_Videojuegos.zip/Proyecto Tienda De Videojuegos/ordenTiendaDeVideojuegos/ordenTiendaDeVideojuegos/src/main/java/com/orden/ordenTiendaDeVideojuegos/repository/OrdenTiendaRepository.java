package com.orden.ordenTiendaDeVideojuegos.repository;

import com.orden.ordenTiendaDeVideojuegos.model.OrdenTienda;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository

public interface OrdenTiendaRepository extends JpaRepository<OrdenTienda, Integer> {

}
