package com.orden.ordenTiendaDeVideojuegos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrdenTiendaDeVideojuegosApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrdenTiendaDeVideojuegosApplication.class, args);
	}

}
