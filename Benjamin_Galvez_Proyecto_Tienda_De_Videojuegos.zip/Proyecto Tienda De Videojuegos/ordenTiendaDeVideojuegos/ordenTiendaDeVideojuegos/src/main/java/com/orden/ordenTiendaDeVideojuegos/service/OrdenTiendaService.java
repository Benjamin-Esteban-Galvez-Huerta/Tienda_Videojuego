package com.orden.ordenTiendaDeVideojuegos.service;

import com.orden.ordenTiendaDeVideojuegos.model.OrdenTienda;
import com.orden.ordenTiendaDeVideojuegos.repository.OrdenTiendaRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service

public class OrdenTiendaService {


    private OrdenTiendaRepository repository;

    public List<OrdenTienda> ListarOrdenes() {
        return repository.findAll();
    }

    public Optional<OrdenTienda> ObtenPorId(Integer id) {
        return repository.findById(id);
    }

    public OrdenTienda GuardarOrden(OrdenTienda orden) {
        return repository.save(orden);
    }

    public void eliminarOrden(Integer id) {
        repository.deleteById(id);
    }

    public OrdenTienda actualizarOrden(Integer id, OrdenTienda orden){
    orden.setId(id);
    return repository.save(orden);
    }
}
