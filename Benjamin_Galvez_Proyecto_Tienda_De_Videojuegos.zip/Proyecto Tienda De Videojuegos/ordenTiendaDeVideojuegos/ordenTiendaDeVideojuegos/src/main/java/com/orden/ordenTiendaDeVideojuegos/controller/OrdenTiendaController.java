package com.orden.ordenTiendaDeVideojuegos.controller;

import com.orden.ordenTiendaDeVideojuegos.model.OrdenTienda;
import com.orden.ordenTiendaDeVideojuegos.service.OrdenTiendaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController

@RequestMapping("/ordenes")
public class OrdenTiendaController {

    @Autowired
    private OrdenTiendaService service;

    @GetMapping
    public List<OrdenTienda> ListarOrdenes() {
        return service.ListarOrdenes();
    }

    @GetMapping("/ordenes/{id}")
    public Optional<OrdenTienda> ObtenPorId(@PathVariable Integer id) {
        return service.ObtenPorId(id);
    }

    @PostMapping("/agregar")
    public OrdenTienda AgregarOrden(@RequestBody OrdenTienda orden) {
        return service.GuardarOrden(orden);
    }

    @DeleteMapping("/Eliminar/{id}")
    public String eliminarOrden(@PathVariable Integer id) {

        Optional<OrdenTienda> ordenExistente = service.ObtenPorId(id);
        if (ordenExistente.isPresent()) {
        service.eliminarOrden(id);
        return "Orden eliminada correctamente";
       } else{
        return "Orden no encontrada con id: " + id;
        }
    } 
    @PutMapping("/actualizar/{id}")
    public String actualizarOrden(@PathVariable Integer id, @RequestBody OrdenTienda orden) {
        Optional<OrdenTienda> ordenExistente = service.ObtenPorId(id);
        if (ordenExistente.isPresent()) {
            service.actualizarOrden(id, orden);
            return "Orden actualizada correctamente";
        } else {
            return "Orden no encontrada con id: " + id;
        }
    }
}