package com.autenticacion.tiendaDeVideojuegos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaDeVideojuegosApplicationTests {

	@Test
	void contextLoads() {
	}

}
