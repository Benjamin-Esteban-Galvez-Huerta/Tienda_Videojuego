package com.autenticacion.tiendaDeVideojuegos.controller;

import com.autenticacion.tiendaDeVideojuegos.model.AutenticacionTienda;
import com.autenticacion.tiendaDeVideojuegos.service.AutenticacionTiendaService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/autenticaciones")
public class AutenticacionTiendaController {

    private final AutenticacionTiendaService service;

    public AutenticacionTiendaController(AutenticacionTiendaService service) {
        this.service = service;
    }

    @GetMapping
    public List<AutenticacionTienda> listarAutenticaciones() {
        return service.listarAutenticaciones();
    }

    @GetMapping("/autenticacion/{id}")
    public Optional<AutenticacionTienda> buscarPorId(@PathVariable Integer id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public AutenticacionTienda crearAutenticacion(@RequestBody AutenticacionTienda autenticacion) {
        return service.guardarAutenticacion(autenticacion);
    }

    @DeleteMapping("/Eliminar/{id}")
    public String eliminar(@PathVariable Integer id) {
        
    Optional<AutenticacionTienda> autenticacion = service.buscarPorId(id);
        if (autenticacion.isPresent()) {
            service.eliminarPorId(id);
            return "Autenticación elimina correctamente";
        } else {
            return "Autenticación no encontrada con ID: " + id;
        }
    }

}
