package com.autenticacion.tiendaDeVideojuegos.service;

import com.autenticacion.tiendaDeVideojuegos.model.AutenticacionTienda;
import com.autenticacion.tiendaDeVideojuegos.repository.AutenticacionTiendaRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AutenticacionTiendaService {

    private final AutenticacionTiendaRepository repository;

    public AutenticacionTiendaService(AutenticacionTiendaRepository repository) {
        this.repository = repository;
    }

    public List<AutenticacionTienda> listarAutenticaciones() {
        return repository.findAll();
    }
    
    public Optional<AutenticacionTienda> buscarPorId(Integer id) {
        return repository.findById(id);
    }

    public AutenticacionTienda guardarAutenticacion(AutenticacionTienda autenticacion) {
        return repository.save(autenticacion);
    }

    public void eliminarPorId(Integer id) {
        repository.deleteById(id);
    }

    public void actualizarAutenticacion(Integer id, AutenticacionTienda autenticacion) {
       autenticacion.setId(id);
        repository.save(autenticacion);
    }
}
