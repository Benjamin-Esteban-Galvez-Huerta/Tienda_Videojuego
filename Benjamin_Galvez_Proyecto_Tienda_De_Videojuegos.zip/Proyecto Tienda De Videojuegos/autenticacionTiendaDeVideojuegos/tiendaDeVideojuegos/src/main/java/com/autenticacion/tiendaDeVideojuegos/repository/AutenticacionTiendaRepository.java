package com.autenticacion.tiendaDeVideojuegos.repository;

import com.autenticacion.tiendaDeVideojuegos.model.AutenticacionTienda;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

//import java.util.Optional;


@Repository
public interface AutenticacionTiendaRepository extends JpaRepository<AutenticacionTienda, Integer> {

}
