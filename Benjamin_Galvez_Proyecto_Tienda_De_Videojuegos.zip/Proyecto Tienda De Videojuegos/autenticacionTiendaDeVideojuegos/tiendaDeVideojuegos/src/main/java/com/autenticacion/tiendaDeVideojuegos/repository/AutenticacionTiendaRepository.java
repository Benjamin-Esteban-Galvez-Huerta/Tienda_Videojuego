package com.autenticacion.tiendaDeVideojuegos.repository;

import com.autenticacion.tiendaDeVideojuegos.model.AutenticacionTienda;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AutenticacionTiendaRepository extends JpaRepository<AutenticacionTienda, Integer> {

}
