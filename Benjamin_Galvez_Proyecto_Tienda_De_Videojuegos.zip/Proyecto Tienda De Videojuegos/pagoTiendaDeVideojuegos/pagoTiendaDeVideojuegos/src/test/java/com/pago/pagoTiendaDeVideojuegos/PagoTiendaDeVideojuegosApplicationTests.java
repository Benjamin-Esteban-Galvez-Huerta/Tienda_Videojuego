package com.pago.pagoTiendaDeVideojuegos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PagoTiendaDeVideojuegosApplicationTests {

	@Test
	void contextLoads() {
	}

}
