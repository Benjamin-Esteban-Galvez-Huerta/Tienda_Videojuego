package com.pago.pagoTiendaDeVideojuegos.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Entity
@Table(name = "pago")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PagoTienda {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotBlank(message = "El nombre del cliente es obligatorio")
    private String nombreCliente;

    @NotBlank(message = "El número de tarjeta es obligatorio")
    @Pattern(regexp = "\\d{16}", message = "El número de tarjeta debe tener 16 dígitos")
    private String numeroTarjeta;

    @NotBlank(message = "La fecha de vencimiento es obligatoria")
    @Pattern(regexp = "(0[1-9]|1[0-2])/(\\d{2}|\\d{4})", message = "La fecha de vencimiento debe tener formato MM/AA o MM/AAAA")
    private String fechaVencimiento;

    @NotBlank(message = "El código de seguridad es obligatorio")
    @Pattern(regexp = "\\d{3}", message = "El código de seguridad debe tener 3 dígitos")
    private String codigoSeguridad;

    @NotNull(message = "El monto es obligatorio")
    @DecimalMin(value = "0.0", inclusive = false, message = "El monto debe ser mayor que cero")
    private BigDecimal monto;
}
