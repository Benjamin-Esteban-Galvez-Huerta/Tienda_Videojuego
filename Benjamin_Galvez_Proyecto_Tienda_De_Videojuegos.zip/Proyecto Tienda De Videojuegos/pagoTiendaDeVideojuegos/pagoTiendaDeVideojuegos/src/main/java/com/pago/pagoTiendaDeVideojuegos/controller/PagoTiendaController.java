package com.pago.pagoTiendaDeVideojuegos.controller;

import com.pago.pagoTiendaDeVideojuegos.model.PagoTienda;
import com.pago.pagoTiendaDeVideojuegos.service.PagoTiendaService;
import org.springframework.web.bind.annotation.*;

import java.util.List; 
import java.util.Optional;

@RestController

@RequestMapping("/pagos")
public class PagoTiendaController {

    
    private PagoTiendaService service;

    @GetMapping
    public List<PagoTienda> listarPagos() {
        return service.listarPagos();
    }

    @GetMapping("/Pago/{id}")
    public Optional<PagoTienda> buscarPorId(@PathVariable Integer id) {
        return service.buscarPorId(id);
    }

    @PostMapping("/agregar")
    public PagoTienda guardarPago(@RequestBody PagoTienda pago) {
        return service.guardarPago(pago);
    }

    @DeleteMapping("/Eliminar/{id}")
    public String eliminarPago(@PathVariable Integer id) {

        Optional<PagoTienda> pagoExistente = service.buscarPorId(id);

        if (pagoExistente.isPresent()) {
            service.eliminarPago(id);
            return "Pago eliminado correctamente";
        } else{
            return "Pago no encontrado con id: " + id;
        }
    }

    @PutMapping("/Actualizar/{id}")
    public String actualizarPago(@PathVariable Integer id, @RequestBody PagoTienda pagoActualizado) {
        
        Optional<PagoTienda> pagoExistente = service.buscarPorId(id);

        if (pagoExistente.isPresent()) {
            return "Pago actualizado correctamente";
        } else {
            return "Pago no encontrado con id: " + id;
        }
    
    }

}
