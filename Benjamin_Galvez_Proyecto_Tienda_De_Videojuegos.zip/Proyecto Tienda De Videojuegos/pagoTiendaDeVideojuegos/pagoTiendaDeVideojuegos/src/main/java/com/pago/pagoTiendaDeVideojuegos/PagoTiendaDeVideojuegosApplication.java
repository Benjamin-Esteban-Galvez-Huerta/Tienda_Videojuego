package com.pago.pagoTiendaDeVideojuegos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PagoTiendaDeVideojuegosApplication {

	public static void main(String[] args) {
		SpringApplication.run(PagoTiendaDeVideojuegosApplication.class, args);
	}

}
