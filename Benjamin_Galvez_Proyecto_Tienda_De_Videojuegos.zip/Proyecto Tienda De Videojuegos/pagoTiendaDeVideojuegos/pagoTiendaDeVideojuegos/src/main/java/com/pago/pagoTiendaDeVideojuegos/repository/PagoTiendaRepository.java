package com.pago.pagoTiendaDeVideojuegos.repository;

import com.pago.pagoTiendaDeVideojuegos.model.PagoTienda;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PagoTiendaRepository extends JpaRepository<PagoTienda, Integer> {

}
