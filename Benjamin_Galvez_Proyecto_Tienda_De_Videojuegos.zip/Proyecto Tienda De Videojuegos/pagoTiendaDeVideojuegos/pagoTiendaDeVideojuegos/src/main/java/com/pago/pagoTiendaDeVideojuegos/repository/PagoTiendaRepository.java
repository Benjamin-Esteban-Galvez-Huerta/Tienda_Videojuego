package com.pago.pagoTiendaDeVideojuegos.repository;

import com.pago.pagoTiendaDeVideojuegos.model.PagoTienda;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository

public interface PagoTiendaRepository extends JpaRepository<PagoTienda, Integer> {

}
