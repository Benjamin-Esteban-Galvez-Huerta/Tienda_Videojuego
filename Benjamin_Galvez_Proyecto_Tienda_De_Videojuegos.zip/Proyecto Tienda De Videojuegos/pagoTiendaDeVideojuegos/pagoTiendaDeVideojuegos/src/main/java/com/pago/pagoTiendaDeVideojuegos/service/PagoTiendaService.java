package com.pago.pagoTiendaDeVideojuegos.service;

import com.pago.pagoTiendaDeVideojuegos.model.PagoTienda;
import com.pago.pagoTiendaDeVideojuegos.repository.PagoTiendaRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class PagoTiendaService {

    
    private PagoTiendaRepository repository;

    public List<PagoTienda> listarPagos() {
        return repository.findAll();
    }

    public Optional<PagoTienda> buscarPorId(Integer id) {
        return repository.findById(id);
    }

    public PagoTienda guardarPago(PagoTienda pago) {
        return repository.save(pago);
    }

    public void eliminarPago(Integer id) {
        repository.deleteById(id);
    }

    public PagoTienda actualizarPago(Integer id, PagoTienda pagoActualizado) {
    pagoActualizado.setId(id);
    return repository.save(pagoActualizado);
    }
}
