package com.reseniaJuegos.tiendaDeVideoJuegos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaDeVideoJuegosApplicationTests {

	@Test
	void contextLoads() {
	}

}
