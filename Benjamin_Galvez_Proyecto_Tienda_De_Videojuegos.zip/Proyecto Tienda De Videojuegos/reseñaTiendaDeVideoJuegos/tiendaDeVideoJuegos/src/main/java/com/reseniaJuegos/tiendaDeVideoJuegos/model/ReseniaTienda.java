package com.reseniaJuegos.tiendaDeVideoJuegos.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import jakarta.validation.constraints.*;



@Entity
@Table(name = "resenia_tienda")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReseniaTienda{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotBlank(message = "El título no puede estar vacío")
    @Size(max = 100, message = "El título no puede exceder 100 caracteres")
    @Column(nullable = false, length = 100)
    private String titulo;

    @NotBlank(message = "El comentario no puede estar vacío")
    @Size(max = 1000, message = "El comentario no puede exceder 1000 caracteres")
    @Column(nullable = false, length = 1000)
    private String comentario;

    @NotNull(message = "La calificación no debe ser 0 ni nula, ni vacia")
    @Min(value = 1, message = "La calificación mínima es 1")
    @Max(value = 5, message = "La calificación máxima es 5")
    @Column(nullable = false)
    private Integer calificacion;

    @NotBlank(message = "El autor no puede estar vacio")
    @Size(max = 60, message = "El nombre del autor no puede exceder 60 caracteres")
    @Column(nullable = false, length = 60)
    private String autor;
}
