package com.reseniaJuegos.tiendaDeVideoJuegos.service;

import com.reseniaJuegos.tiendaDeVideoJuegos.model.ReseniaTienda;
import com.reseniaJuegos.tiendaDeVideoJuegos.repository.ReseniaTiendaRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service

public class ReseniaTiendaService {

    private final ReseniaTiendaRepository repository;

    ReseniaTiendaService(ReseniaTiendaRepository repository) {
        this.repository = repository;
    }

    public List<ReseniaTienda> ListarResenia() {
        return repository.findAll();
    }

    public Optional<ReseniaTienda> buscarPorId(Integer id) {
        return repository.findById(id);
    }

    public ReseniaTienda guardarResenia(ReseniaTienda resenia) {
        return repository.save(resenia);
    }

    public void eliminarResenia(Integer id) {
        repository.deleteById(id);
    }

    public ReseniaTienda actualizarResenia(Integer id, ReseniaTienda reseniaActualizada) {
    reseniaActualizada.setId(id);
    return repository.save(reseniaActualizada);
    }
}
