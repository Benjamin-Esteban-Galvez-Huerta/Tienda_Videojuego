package com.reseniaJuegos.tiendaDeVideoJuegos.repository;

import com.reseniaJuegos.tiendaDeVideoJuegos.model.ReseniaTienda;
import org.springframework.data.jpa.repository.JpaRepository;

//import java.util.List;
//import java.util.Optional;

public interface ReseniaTiendaRepository extends JpaRepository<ReseniaTienda, Integer> {
}
