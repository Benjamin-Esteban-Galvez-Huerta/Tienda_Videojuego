package com.reseniaJuegos.tiendaDeVideoJuegos.repository;

import com.reseniaJuegos.tiendaDeVideoJuegos.model.ReseniaTienda;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

//import java.util.List;
//import java.util.Optional;

@Repository
public interface ReseniaTiendaRepository extends JpaRepository<ReseniaTienda, Integer> {
}
