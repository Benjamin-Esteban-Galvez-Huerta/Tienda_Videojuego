package com.reseniaJuegos.tiendaDeVideoJuegos.controller;

import com.reseniaJuegos.tiendaDeVideoJuegos.model.ReseniaTienda;
import com.reseniaJuegos.tiendaDeVideoJuegos.service.ReseniaTiendaService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController

@RequestMapping("/resenias")
public class ReseniaTiendaController {

    private final ReseniaTiendaService service;

    ReseniaTiendaController(ReseniaTiendaService service) {
        this.service = service;
    }

    @GetMapping
    public List<ReseniaTienda> ListarResenia() {
        return service.ListarResenia();
    }

    @GetMapping("/Pelicula/{id}")
    public Optional<ReseniaTienda> buscarPorId(@PathVariable Integer id) {
        return service.buscarPorId(id);
    }

    @PostMapping("/agregar")
    public ReseniaTienda crearResenia(@RequestBody ReseniaTienda resenia) {
        return service.guardarResenia(resenia);
    }

    @DeleteMapping("/Eliminar/{id}")
    public String eliminarResenia(@PathVariable Integer id) {
        Optional <ReseniaTienda> resenia = service.buscarPorId(id);

        if (resenia.isPresent()) {
          service.eliminarResenia(id);
          return "Reseña eliminada correctamente.";
        } else {
          return "Reseña no encontrada con el ID: " + id;
        }
    }

    @PutMapping("/actualizar/{id}")
    public String actualizarResenia(@PathVariable Integer id, @RequestBody ReseniaTienda reseniaActualizada) {
        Optional<ReseniaTienda> reseniaExistente = service.buscarPorId(id);

        if (reseniaExistente.isPresent()) {
            service.actualizarResenia(id, reseniaActualizada);
            return "Reseña actualizada correctamente.";
        } else {
            return "Reseña no encontrada con el ID: " + id;
        }
    }
}